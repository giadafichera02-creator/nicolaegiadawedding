# The Wedding Book V5

Questa versione incorpora direttamente le fotografie nel file HTML di anteprima.
Per questo motivo le immagini non dipendono da link esterni e dovrebbero essere sempre visibili.

- Apri `index.html`
- Oppure usa il file di anteprima fornito separatamente
